/**
    MLX9064x_Universal — implementation. Apache License 2.0.
    See MLX9064x_Universal.h for documentation.
*/
#include <Wire.h>
#include "MLX9064x_Universal.h"

// Error codes returned via lastError():
//  -10 sensor not ACKing at the I2C address
//  -11 EEPROM deviceSelect word read failed
//  -12 EEPROM dump failed
//  -13 calibration parameter extraction failed
//  -14 setRefreshRate failed
//  -20 frame acquisition failed (I2C)
//  -21 readFrame called before successful begin()

const char* MLX9064xUniversal::chipName() const {
    switch (_chip) {
        case MLX9064X_MLX90640: return "MLX90640 (32x24)";
        case MLX9064X_MLX90641: return "MLX90641 (16x12)";
        default:                return "UNKNOWN";
    }
}

int MLX9064xUniversal::readEEWord(uint16_t eeAddress, uint16_t* word) {
    return MLX9064x_I2CRead(_addr, eeAddress, 1, word);
}

bool MLX9064xUniversal::begin(uint32_t i2cClockHz, bool initWire) {
    _lastError = 0;
    _chip = MLX9064X_UNKNOWN;

    if (initWire) {
        Wire.begin();
    }
    Wire.setClock(i2cClockHz);

    // [1] Probe: does anything ACK at the address?
    Wire.beginTransmission(_addr);
    if (Wire.endTransmission() != 0) {
        _lastError = -10;
        return false;
    }

    // [2] Auto-detect chip type from EEPROM 0x240A bit 6 (deviceSelect).
    //     1 -> MLX90641 (16x12), 0 -> MLX90640 (32x24).
    uint16_t devWord;
    if (MLX9064x_I2CRead(_addr, 0x240A, 1, &devWord) != 0) {
        _lastError = -11;
        return false;
    }
    _chip = (devWord & 0x0040) ? MLX9064X_MLX90641 : MLX9064X_MLX90640;

    // [3] Dump factory EEPROM (832 words for both chips) and extract
    //     the calibration parameters with the official Melexis math.
    static uint16_t ee[832];   // static: keep it off the stack
    int status;
    if (_chip == MLX9064X_MLX90641) {
        status = MLX90641_DumpEE(_addr, ee);
        if (status != 0) { _lastError = -12; return false; }
        status = MLX90641_ExtractParameters(ee, &_p41);
        if (status != 0) { _lastError = -13; return false; }
    } else {
        status = MLX90640_DumpEE(_addr, ee);
        if (status != 0) { _lastError = -12; return false; }
        status = MLX90640_ExtractParameters(ee, &_p40);
        if (status != 0) { _lastError = -13; return false; }
        MLX90640_SetChessMode(_addr);   // recommended pattern for 90640
    }

    // [4] Sensible default refresh rate.
    if (!setRefreshRate(MLX9064X_RATE_4HZ)) {
        _lastError = -14;
        return false;
    }
    return true;
}

bool MLX9064xUniversal::setRefreshRate(MLX9064xRate rate) {
    int status;
    if (_chip == MLX9064X_MLX90641) {
        status = MLX90641_SetRefreshRate(_addr, (uint8_t)rate);
    } else if (_chip == MLX9064X_MLX90640) {
        status = MLX90640_SetRefreshRate(_addr, (uint8_t)rate);
    } else {
        return false;
    }
    return status == 0;
}

int MLX9064xUniversal::readFrame(float* dest) {
    if (_chip == MLX9064X_UNKNOWN) {
        _lastError = -21;
        return _lastError;
    }
    _lastError = 0;

    if (_chip == MLX9064X_MLX90641) {
        // MLX90641: every subpage carries all 192 pixels.
        int status = MLX90641_GetFrameData(_addr, _frame);
        if (status < 0) { _lastError = -20; return _lastError; }
        _lastVdd = MLX90641_GetVdd(_frame, &_p41);
        _lastTa  = MLX90641_GetTa(_frame, &_p41);
        float tr = _lastTa - _taShift;   // reflected temperature estimate
        MLX90641_CalculateTo(_frame, &_p41, _emissivity, tr, dest);
    } else {
        // MLX90640: a full image is two interleaved subpages.
        for (uint8_t sp = 0; sp < 2; sp++) {
            int status = MLX90640_GetFrameData(_addr, _frame);
            if (status < 0) { _lastError = -20; return _lastError; }
            _lastVdd = MLX90640_GetVdd(_frame, &_p40);
            _lastTa  = MLX90640_GetTa(_frame, &_p40);
            float tr = _lastTa - _taShift;
            MLX90640_CalculateTo(_frame, &_p40, _emissivity, tr, dest);
        }
    }
    return 0;
}
