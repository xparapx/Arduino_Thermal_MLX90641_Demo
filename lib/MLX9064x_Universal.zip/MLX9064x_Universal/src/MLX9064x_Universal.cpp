/**
    MLX9064x_Universal.cpp — 칩 자동판별 구현 (physics-jh, 2026-06)
*/
#include <Wire.h>
#include <Arduino.h>
#include "MLX9064x_Universal.h"

MlxChip MLX9064x_DetectChip(uint8_t slaveAddr) {
    // EEPROM 0x240A 1워드 읽기
    Wire.beginTransmission(slaveAddr);
    Wire.write(0x24);
    Wire.write(0x0A);
    if (Wire.endTransmission(false) != 0) return MLX_CHIP_UNKNOWN;  // NACK
    if (Wire.requestFrom((int)slaveAddr, 2) != 2) return MLX_CHIP_UNKNOWN;
    uint16_t w = ((uint16_t)Wire.read() << 8) | Wire.read();

    // bit6 = deviceSelect
    return (w & 0x0040) ? MLX_CHIP_90641 : MLX_CHIP_90640;
}

int MLX9064x_PixelCount(MlxChip chip) {
    switch (chip) {
        case MLX_CHIP_90641: return 192;   // 16×12
        case MLX_CHIP_90640: return 768;   // 32×24
        default:             return 0;
    }
}

const char* MLX9064x_ChipName(MlxChip chip) {
    switch (chip) {
        case MLX_CHIP_90641: return "MLX90641";
        case MLX_CHIP_90640: return "MLX90640";
        default:             return "UNKNOWN";
    }
}
