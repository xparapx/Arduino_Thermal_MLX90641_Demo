/**
    MLX9064x_Universal — unified wrapper for Melexis MLX90640 (32x24)
    and MLX90641 (16x12) thermal IR arrays (Seeed Grove Thermal Imaging
    Camera, both variants share I2C address 0x33).

    The chip type is AUTO-DETECTED from the factory EEPROM deviceSelect
    bit (word 0x240A, bit 6: 1 = MLX90641, 0 = MLX90640), so the same
    sketch runs unmodified on either module.

    Built on the unmodified Melexis calibration math (MLX9064x_API) with
    a rewritten ESP32-safe I2C driver. Apache License 2.0.

    Basic use:
        MLX9064xUniversal cam;
        float frame[MLX9064X_MAX_PIXELS];
        cam.begin();                 // Wire.begin() + detect + calibrate
        cam.readFrame(frame);        // blocking, returns 0 on success
        cam.width(); cam.height();   // 32x24 or 16x12
        cam.getTa(); cam.getVdd();   // ambient temp / supply voltage
*/
#ifndef _MLX9064X_UNIVERSAL_H_
#define _MLX9064X_UNIVERSAL_H_

#include <Arduino.h>
#include "MLX90640_API.h"
#include "MLX90641_API.h"
#include "MLX9064X_I2C_Driver.h"

#define MLX9064X_MAX_PIXELS 768   // MLX90640: 768, MLX90641: 192

enum MLX9064xChip {
    MLX9064X_UNKNOWN = 0,
    MLX9064X_MLX90640,   // 32 x 24
    MLX9064X_MLX90641    // 16 x 12
};

// Refresh-rate codes shared by both chips (control register field).
enum MLX9064xRate {
    MLX9064X_RATE_0_5HZ = 0x00,
    MLX9064X_RATE_1HZ   = 0x01,
    MLX9064X_RATE_2HZ   = 0x02,
    MLX9064X_RATE_4HZ   = 0x03,
    MLX9064X_RATE_8HZ   = 0x04,
    MLX9064X_RATE_16HZ  = 0x05,
    MLX9064X_RATE_32HZ  = 0x06,
    MLX9064X_RATE_64HZ  = 0x07
};

class MLX9064xUniversal {
  public:
    MLX9064xUniversal(uint8_t i2cAddress = 0x33) : _addr(i2cAddress) {}

    // Initializes Wire (unless initWire=false), probes the sensor,
    // auto-detects the chip from EEPROM, loads calibration parameters.
    // Returns true on success. On failure see lastError().
    bool begin(uint32_t i2cClockHz = 400000, bool initWire = true);

    // Identification ----------------------------------------------------
    MLX9064xChip chip() const        { return _chip; }
    const char*  chipName() const;
    uint16_t     width() const       { return _chip == MLX9064X_MLX90641 ? 16 : 32; }
    uint16_t     height() const      { return _chip == MLX9064X_MLX90641 ? 12 : 24; }
    uint16_t     pixelCount() const  { return width() * height(); }

    // Configuration ------------------------------------------------------
    bool setRefreshRate(MLX9064xRate rate);
    void setEmissivity(float e)      { _emissivity = e; }      // default 0.95
    void setTaShift(float shift)     { _taShift = shift; }     // default 8.0

    // Acquisition ----------------------------------------------------------
    // Reads one complete thermal frame (both subpages for MLX90640) and
    // writes pixelCount() calibrated temperatures (deg C, row-major) into
    // dest. dest must hold at least pixelCount() floats
    // (MLX9064X_MAX_PIXELS is always safe). Returns 0 on success,
    // negative on error (value of lastError()).
    int readFrame(float* dest);

    // Values from the most recent successful readFrame():
    float getTa() const   { return _lastTa;  }   // ambient (chip) temp, deg C
    float getVdd() const  { return _lastVdd; }   // supply voltage, V

    int  lastError() const { return _lastError; }

    // Low-level escape hatch: raw EEPROM word (addr 0x2400..0x273F).
    int readEEWord(uint16_t eeAddress, uint16_t* word);

  private:
    uint8_t       _addr;
    MLX9064xChip  _chip = MLX9064X_UNKNOWN;
    float         _emissivity = 0.95f;
    float         _taShift = 8.0f;
    float         _lastTa = NAN, _lastVdd = NAN;
    int           _lastError = 0;

    paramsMLX90640 _p40;
    paramsMLX90641 _p41;
    uint16_t       _frame[834];   // big enough for MLX90640 (834) / 90641 (242)
};

#endif
