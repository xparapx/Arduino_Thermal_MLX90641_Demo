/**
    MLX9064x_Universal.h — 칩 자동판별 헤더 (physics-jh, 2026-06)

    EEPROM 0x240A 의 bit6(deviceSelect)로 센서를 자동 판별한다:
        bit6 = 1 → MLX90641 (16×12, 192픽셀)
        bit6 = 0 → MLX90640 (32×24, 768픽셀)

    이렇게 하면 펌웨어에서 "어느 칩인지" 가정하지 않고, 런타임에 확인 후
    올바른 API(MLX90641_API / MLX90640_API)를 선택할 수 있다.
    (이번 트러블슈팅의 1차 원인이 칩 오인이었음 — 자동판별로 재발 방지.)
*/
#ifndef _MLX9064x_Universal_H_
#define _MLX9064x_Universal_H_

#include <stdint.h>

enum MlxChip {
    MLX_CHIP_UNKNOWN = 0,
    MLX_CHIP_90640   = 90640,  // 32×24
    MLX_CHIP_90641   = 90641   // 16×12
};

// I2C 0x33(기본)에 연결된 칩을 판별. 통신 실패 시 MLX_CHIP_UNKNOWN.
MlxChip MLX9064x_DetectChip(uint8_t slaveAddr = 0x33);

// 판별된 칩의 픽셀 수 (90641=192, 90640=768, 미확인=0)
int MLX9064x_PixelCount(MlxChip chip);

// 사람이 읽는 이름 문자열 ("MLX90641" 등)
const char* MLX9064x_ChipName(MlxChip chip);

#endif
