/**
    @copyright (C) 2017 Melexis N.V.  (Apache-2.0)

    ── 패치 안내 (physics-jh, 2026-06) ─────────────────────────────────
    원본 Seeed_Arduino_MLX9064x 의 MLX9064x_I2CRead() 는 ESP32에서
      ① NACK 시 return(0) 으로 "실패를 성공으로" 보고
      ② requestFrom() 수신 바이트 수를 검증하지 않음 (Wire.available()만 확인)
    → 깨진/동결된 프레임이 그대로 흘러 H:7,844℃·NaN 등 가짜 패턴 발생.

    아래 MLX9064x_I2CRead() 는 32바이트(16워드) 단위 분할 읽기 +
    실패를 실패(-1)로 전파하도록 교체한 버전. (Nano ESP32 검증 완료)
    나머지 함수(Init/Write/FreqSet)는 원본과 동일.
    ────────────────────────────────────────────────────────────────────
*/

#include <Wire.h>
#include <Arduino.h>

#include "MLX9064X_I2C_Driver.h"

void MLX9064x_I2CInit() {
}

// startAddress 부터 nWordsRead 워드를 읽어 data[]에 저장.
// 성공 0, 실패 -1.  (ESP32 호환 패치본)
int MLX9064x_I2CRead(uint8_t slaveAddr, unsigned int startAddress,
                     unsigned int nWordsRead, uint16_t* data) {
    const unsigned int CHUNK = 16;  // 16워드=32바이트, ESP32 Wire 버퍼에서 안정
    for (unsigned int i = 0; i < nWordsRead; i += CHUNK) {
        unsigned int cnt = (nWordsRead - i < CHUNK) ? (nWordsRead - i) : CHUNK;
        Wire.beginTransmission(slaveAddr);
        Wire.write((startAddress + i) >> 8);    // MSB
        Wire.write((startAddress + i) & 0xFF);  // LSB
        if (Wire.endTransmission(false) != 0) return -1;  // NACK → 실패 반환
        if (Wire.requestFrom((int)slaveAddr, (int)(cnt * 2)) != (int)(cnt * 2))
            return -1;  // 수신 바이트 수 불일치 → 실패 반환
        for (unsigned int j = 0; j < cnt; j++)
            data[i + j] = ((uint16_t)Wire.read() << 8) | Wire.read();
    }
    return 0;
}

// I2C Freq, kHz 단위. MLX9064x_I2CFreqSet(1000) → 1MHz
void MLX9064x_I2CFreqSet(int freq) {
    Wire.setClock((long)1000 * freq);
}

// 2바이트 주소에 2바이트 기록 + 검증
int MLX9064x_I2CWrite(uint8_t slaveAddr, unsigned int writeAddress, uint16_t data) {
    Wire.beginTransmission((uint8_t)slaveAddr);
    Wire.write(writeAddress >> 8);
    Wire.write(writeAddress & 0xFF);
    Wire.write(data >> 8);
    Wire.write(data & 0xFF);
    if (Wire.endTransmission() != 0) return -1;

    uint16_t dataCheck;
    if (MLX9064x_I2CRead(slaveAddr, writeAddress, 1, &dataCheck) != 0) return -1;
    if (dataCheck != data) return -2;
    return 0;
}
