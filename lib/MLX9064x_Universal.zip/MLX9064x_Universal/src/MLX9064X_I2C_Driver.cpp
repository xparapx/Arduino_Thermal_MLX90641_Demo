/**
    @copyright (C) 2017 Melexis N.V.

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.

    -------------------------------------------------------------------
    MODIFIED (MLX9064x_Universal, 2026):
    Rewritten MLX9064x_I2CRead() to fix silent data corruption on
    ESP32-family boards (e.g. Arduino Nano ESP32):
      1. Original returned 0 (success) on NACK -> errors were invisible.
      2. Original did not verify the number of bytes actually received
         by Wire.requestFrom(); on ESP32 a partially-failed chunk left
         stale/0xFF data in the buffer, producing deterministic garbage
         frames ("frozen" non-physical temperatures).
      3. Chunk size is now fixed at 32 bytes (16 words) per transaction
         with a repeated-start address rewrite for every chunk, which is
         verified stable on ESP32 Arduino cores.
    All errors now propagate as -1 so callers can retry.
    -------------------------------------------------------------------
*/
#include <Wire.h>
#include <Arduino.h>
#include "MLX9064X_I2C_Driver.h"

// Words per I2C transaction. 16 words = 32 bytes: safe on every Arduino
// core (AVR BUFFER_LENGTH=32, ESP32 I2C_BUFFER_LENGTH=128, SAMD, RP2040...).
#ifndef MLX9064X_CHUNK_WORDS
#define MLX9064X_CHUNK_WORDS 16
#endif

void MLX9064x_I2CInit() {
}

// Read a number of 16-bit words starting at startAddress into data[].
// Returns 0 on success, -1 on any I2C error (NACK / short read).
int MLX9064x_I2CRead(uint8_t slaveAddr, unsigned int startAddress,
                     unsigned int nWordsRead, uint16_t* data) {
    unsigned int i = 0;
    while (i < nWordsRead) {
        unsigned int cnt = nWordsRead - i;
        if (cnt > MLX9064X_CHUNK_WORDS) {
            cnt = MLX9064X_CHUNK_WORDS;
        }

        // Re-issue the address pointer for every chunk (repeated start).
        Wire.beginTransmission(slaveAddr);
        Wire.write((uint8_t)((startAddress + i) >> 8));   // MSB
        Wire.write((uint8_t)((startAddress + i) & 0xFF)); // LSB
        if (Wire.endTransmission(false) != 0) {
            return -1;  // NACK: report failure (original code returned 0 here!)
        }

        // Explicit (int,int) overload avoids the ambiguous-overload issue
        // seen on ESP32 cores, and the return value is strictly verified.
        int received = Wire.requestFrom((int)slaveAddr, (int)(cnt * 2));
        if (received != (int)(cnt * 2)) {
            return -1;  // short read: do NOT silently keep stale data
        }

        for (unsigned int j = 0; j < cnt; j++) {
            uint16_t msb = (uint16_t)Wire.read();
            uint16_t lsb = (uint16_t)Wire.read();
            data[i + j] = (uint16_t)((msb << 8) | lsb);
        }
        i += cnt;
    }
    return 0;
}

// Set I2C frequency in kHz. MLX9064x_I2CFreqSet(400) -> 400 kHz.
void MLX9064x_I2CFreqSet(int freq) {
    Wire.setClock((long)1000 * freq);
}

// Write one 16-bit word to a 16-bit register address, then read back
// to verify. Returns 0 on success, -1 on NACK, -2 on verify mismatch.
int MLX9064x_I2CWrite(uint8_t slaveAddr, unsigned int writeAddress,
                      uint16_t data) {
    Wire.beginTransmission(slaveAddr);
    Wire.write((uint8_t)(writeAddress >> 8));   // MSB
    Wire.write((uint8_t)(writeAddress & 0xFF)); // LSB
    Wire.write((uint8_t)(data >> 8));           // MSB
    Wire.write((uint8_t)(data & 0xFF));         // LSB
    if (Wire.endTransmission() != 0) {
        return -1;  // sensor did not ACK
    }

    uint16_t dataCheck;
    if (MLX9064x_I2CRead(slaveAddr, writeAddress, 1, &dataCheck) != 0) {
        return -1;
    }
    if (dataCheck != data) {
        return -2;  // the write did not stick
    }
    return 0;
}
