# MLX9064x_Universal

ESP32에서 깨지던 **Seeed_Arduino_MLX9064x** 를 고친 포크 라이브러리. MLX90640/90641 열화상 어레이용.

## 왜 만들었나

공식 라이브러리의 `MLX9064x_I2CRead()` 는 ESP32에서 두 가지 결함이 있다:
- **NACK인데 `return(0)`** — 실패를 성공으로 보고
- **`requestFrom()` 수신량 미검증** — `Wire.available()`만 보고 부족분 무시

→ 깨지거나 동결된 프레임이 그대로 흘러 `H:7,844℃`·`NaN` 같은 가짜 패턴이 나온다. (Seeed 이슈 트래커에 미보고, master에 결함 잔존.)

## 무엇을 고쳤나

- `MLX9064X_I2C_Driver.cpp` — **32바이트 청크 읽기 + 실패를 -1로 전파** (Nano ESP32 검증)
- `MLX9064x_Universal.h/.cpp` — **칩 자동판별** 래퍼 추가. EEPROM `0x240A` bit6로 90640/90641 구분
- 보정 수학(Melexis `MLX90640_API`, `MLX90641_API`)은 **원본 그대로 유지**

## 설치

Arduino IDE → `스케치 → 라이브러리 포함하기 → .ZIP 라이브러리 추가` → 이 ZIP 선택. **드라이버 파일을 손으로 패치할 필요 없음.**

## 예제

| 예제 | 용도 |
|---|---|
| `01_Diagnostic` | 30초 진단 (ACK·칩 판별·통신 무결성) |
| `02_SerialStream_UI` | Web Serial UI용 CSV 스트리밍 (실제 펌웨어 투입 위치) |
| `03_BasicReadings` | MLX90641 한 프레임 읽어 Ta/min/max/center 출력 |

## 주의

- 헤더명은 `MLX9064X_I2C_Driver.h` (X 대문자, 9064 X 공용)
- 칩 종류에 맞는 API 사용: 90641 → `MLX90641_API.h`, 90640 → `MLX90640_API.h`
- I2C: ESP32에서 100kHz 권장, SDA=A4 / SCL=A5

기반: [Seeed-Studio/Seeed_Arduino_MLX9064x](https://github.com/Seeed-Studio/Seeed_Arduino_MLX9064x) · License: Apache-2.0
