# MLX9064x_Universal

Melexis **MLX90640 (32×24)** / **MLX90641 (16×12)** 열화상 어레이 범용 Arduino 라이브러리.
Seeed Grove Thermal Imaging Camera 두 변종(동일 I2C 주소 0x33)을 **칩 자동판별**로 모두 지원하며,
ESP32 계열 보드에서 발생하는 **무음 데이터 손상(동결된 쓰레기 프레임, Vdd=inf)** 문제를 수정한
I2C 드라이버를 내장합니다.

## 무엇이 다른가 (vs Seeed_Arduino_MLX9064x 원본)

| 항목 | 원본 | 본 라이브러리 |
|---|---|---|
| I2C 읽기 실패(NACK) | `return 0` — **실패를 성공으로 보고** | `-1` 반환, 호출부에서 재시도 가능 |
| `requestFrom` 수신량 | 미검증 → 부분 수신 시 이전/0xFF 데이터 잔류 | 바이트 수 엄격 검증, 미달 시 오류 |
| 청크 크기 | 플랫폼 매크로 의존(충돌 가능) | 16워드(32바이트) 고정 — 전 플랫폼 안전 |
| 칩 선택 | 사용자가 90640/90641 API를 직접 골라야 함 (틀리면 Vdd=inf, 전픽셀 NaN) | EEPROM 0x240A bit6으로 **자동판별** |
| 보정 수학 | Melexis 공식 | **동일 (무수정)** — 정확도 보장 |

## 설치

Arduino IDE → 스케치 → 라이브러리 포함하기 → .ZIP 라이브러리 추가 → `MLX9064x_Universal.zip` 선택.

> ⚠ 기존 `Seeed_Arduino_MLX9064x`가 설치되어 있다면 **삭제 또는 폴더 이동**을 권장합니다.
> 두 라이브러리는 같은 이름의 내부 헤더(`MLX90640_API.h` 등)를 갖고 있어,
> 스케치가 그 헤더를 직접 include하면 IDE가 엉뚱한 쪽을 선택할 수 있습니다.
> (`MLX9064x_Universal.h`만 include하면 충돌하지 않습니다.)

## 최소 사용 예

```cpp
#include <MLX9064x_Universal.h>

MLX9064xUniversal cam;
float frame[MLX9064X_MAX_PIXELS];   // 어느 칩이든 안전

void setup() {
  Serial.begin(115200);
  cam.begin();                       // Wire.begin + 400kHz + 자동판별 + 보정 로드
  Serial.println(cam.chipName());    // "MLX90641 (16x12)" 등
  cam.setRefreshRate(MLX9064X_RATE_8HZ);
}

void loop() {
  if (cam.readFrame(frame) == 0) {
    // frame[0 .. cam.pixelCount()-1] = 보정 온도(℃), row-major
  }
}
```

## API 요약

- `bool begin(uint32_t i2cClockHz = 400000, bool initWire = true)`
- `int readFrame(float* dest)` — 0=성공. 90640은 subpage 2회 자동 처리
- `chip() / chipName() / width() / height() / pixelCount()`
- `setRefreshRate(MLX9064X_RATE_0_5HZ ... _64HZ)` · `setEmissivity(float)` (기본 0.95) · `setTaShift(float)` (기본 8.0)
- `getTa() / getVdd()` — 최근 프레임의 주변온도/전원전압
- `lastError()` — -10 배선, -12 EEPROM, -13 보정추출, -20 프레임 I2C 실패

## 정상 동작 기준값 (Nano ESP32 + Grove MLX90641 실측)

Vdd 3.0~3.3V · Ta 실온+3~8℃ · 배경 픽셀 실온±2℃ · 손 33~36℃ · NaN 0개 ·
프레임 간 ±0.1~0.3℃ 자연 요동 (**완전히 동일한 값이 반복되면 비정상**).

## 라이선스

Apache License 2.0. 보정 수학은 Melexis N.V. 공식 MLX9064x API(© 2017 Melexis, Seeed-Studio 배포본)를
무수정 포함하며, I2C 드라이버(`MLX9064X_I2C_Driver.cpp`)는 ESP32 호환을 위해 재작성되었습니다
(수정 내역은 파일 헤더 참조).
