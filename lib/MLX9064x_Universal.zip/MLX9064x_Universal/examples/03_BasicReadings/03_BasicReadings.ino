/*
  03_BasicReadings — MLX90641 한 프레임 읽어 온도 출력 (정석 흐름)
  보드: Arduino Nano ESP32 / I2C: SDA=A4, SCL=A5 / 0x33
  먼저 01_Diagnostic 으로 ACK·칩 판별이 정상인지 확인할 것.
*/
#include <Wire.h>
#include "MLX90641_API.h"
#include "MLX9064X_I2C_Driver.h"

#define MLX_ADDR    0x33
#define TA_SHIFT    8        // 반사 온도 = Ta - TA_SHIFT
#define EMISSIVITY  0.95f

static uint16_t eeData[832];
static uint16_t frameData[242];
static paramsMLX90641 params;
static float result[192];    // 16×12

void setup() {
  Serial.begin(115200);
  while (!Serial) delay(10);
  delay(500);
  Wire.begin();
  Wire.setClock(100000);     // ESP32 안정성

  if (MLX90641_DumpEE(MLX_ADDR, eeData) != 0) {
    Serial.println("EEPROM dump 실패 — 배선/패치 확인"); while (1) delay(1000);
  }
  if (MLX90641_ExtractParameters(eeData, &params) != 0) {
    Serial.println("파라미터 추출 실패 — 칩 종류/EEPROM 확인"); while (1) delay(1000);
  }
  MLX90641_SetRefreshRate(MLX_ADDR, 0x05);  // 16Hz
  Serial.println("init OK");
}

void loop() {
  if (MLX90641_GetFrameData(MLX_ADDR, frameData) < 0) {
    Serial.println("프레임 읽기 실패"); delay(200); return;
  }
  float Ta = MLX90641_GetTa(frameData, &params);
  float tr = Ta - TA_SHIFT;
  MLX90641_CalculateTo(frameData, &params, EMISSIVITY, tr, result);

  float mn = result[0], mx = result[0];
  for (int i = 1; i < 192; i++) { if (result[i] < mn) mn = result[i]; if (result[i] > mx) mx = result[i]; }
  Serial.printf("Ta=%.1f  min=%.1f  max=%.1f  center=%.1f\n",
                Ta, mn, mx, result[96]);  // 중앙 부근
  delay(250);
}
