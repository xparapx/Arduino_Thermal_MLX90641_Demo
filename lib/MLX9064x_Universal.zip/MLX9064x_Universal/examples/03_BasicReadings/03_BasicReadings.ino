/*
  MLX9064x_Universal — 03_BasicReadings
  2초마다 온도 그리드를 텍스트로 출력하는 최소 예제.
*/
#include <MLX9064x_Universal.h>

MLX9064xUniversal cam;
float frame[MLX9064X_MAX_PIXELS];

void setup() {
  Serial.begin(115200);
  while (!Serial) delay(10);
  if (!cam.begin()) {
    while (1) { Serial.printf("init error %d\n", cam.lastError()); delay(1000); }
  }
  Serial.printf("%s ready\n", cam.chipName());
}

void loop() {
  if (cam.readFrame(frame) == 0) {
    for (uint16_t r = 0; r < cam.height(); r++) {
      for (uint16_t c = 0; c < cam.width(); c++) {
        Serial.printf("%5.1f ", frame[r * cam.width() + c]);
      }
      Serial.println();
    }
    Serial.printf("Ta=%.1fC Vdd=%.2fV\n\n", cam.getTa(), cam.getVdd());
  }
  delay(2000);
}
