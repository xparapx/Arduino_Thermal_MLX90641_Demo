/*
  MLX9064x_Universal — 01_Diagnostic
  칩 자동판별 + 보정 로드 + 프레임 품질 진단.
  시리얼 모니터 115200. 센서에 손을 대면 center/max가 33~36℃로 반응해야 정상.
*/
#include <MLX9064x_Universal.h>

MLX9064xUniversal cam;                 // 기본 I2C 주소 0x33
float frame[MLX9064X_MAX_PIXELS];      // 어느 칩이든 안전한 크기

void setup() {
  Serial.begin(115200);
  while (!Serial) delay(10);
  delay(500);

  Serial.println("\n=== MLX9064x Universal Diagnostic ===");
  if (!cam.begin()) {                  // Wire.begin + 400kHz + 자동판별 + 보정
    Serial.printf("begin() FAILED, lastError=%d\n", cam.lastError());
    Serial.println("(-10 배선/전원, -12 EEPROM, -13 보정추출 실패)");
    while (1) delay(1000);
  }
  Serial.printf("Detected chip : %s\n", cam.chipName());
  Serial.printf("Resolution    : %u x %u (%u px)\n",
                cam.width(), cam.height(), cam.pixelCount());
  cam.setRefreshRate(MLX9064X_RATE_4HZ);
  Serial.println("Frame loop start — put your hand in front of the sensor\n");
}

void loop() {
  if (cam.readFrame(frame) != 0) {
    Serial.printf("readFrame ERR %d\n", cam.lastError());
    delay(200);
    return;
  }

  const uint16_t n = cam.pixelCount();
  float tMin = 999, tMax = -999;
  uint16_t nanCnt = 0;
  for (uint16_t i = 0; i < n; i++) {
    if (isnan(frame[i])) { nanCnt++; continue; }
    if (frame[i] < tMin) tMin = frame[i];
    if (frame[i] > tMax) tMax = frame[i];
  }
  uint16_t centerIdx = (cam.height() / 2) * cam.width() + cam.width() / 2;

  Serial.printf("Vdd=%.2fV Ta=%5.1fC | center=%6.1f min=%6.1f max=%6.1f NaN=%u\n",
                cam.getVdd(), cam.getTa(), frame[centerIdx], tMin, tMax, nanCnt);
}
