/*
  01_Diagnostic — 30초 진단 (라이브러리 무관 + 자동판별)
  ACK → 칩 판별 → 통신 무결성을 한 번에 점검.
  결과는 시리얼 모니터(115200)로 확인.
*/
#include <Wire.h>
#include "MLX9064x_Universal.h"

void setup() {
  Serial.begin(115200);
  while (!Serial) delay(10);
  delay(500);
  Wire.begin();
  Wire.setClock(100000);  // ESP32 안정성 위해 100kHz

  // [1] 0x33 ACK — 배선/전원
  Wire.beginTransmission(0x33);
  Serial.printf("ACK: %s\n", Wire.endTransmission() == 0 ? "OK" : "FAIL(배선!)");

  // [2] 칩 판별 (래퍼 사용)
  MlxChip chip = MLX9064x_DetectChip(0x33);
  Serial.printf("CHIP: %s (%d px)\n",
                MLX9064x_ChipName(chip), MLX9064x_PixelCount(chip));

  // [3] 같은 주소 2회 독취 일치 = 통신 무결성
  uint16_t a[2];
  for (int t = 0; t < 2; t++) {
    Wire.beginTransmission(0x33); Wire.write(0x24); Wire.write(0x30);
    Wire.endTransmission(false); Wire.requestFrom(0x33, 2);
    a[t] = (Wire.read() << 8) | Wire.read();
  }
  Serial.printf("0x2430(gain)=0x%04X, 재독취 %s\n", a[0],
                a[0] == a[1] ? "일치(통신 OK)" : "불일치(신호 문제!)");
}

void loop() { delay(10000); }
