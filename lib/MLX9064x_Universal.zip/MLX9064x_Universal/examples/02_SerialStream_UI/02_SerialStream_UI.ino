/*
  MLX9064x_Universal — 02_SerialStream_UI
  Web Serial 기반 열화상 UI(HTML 앱)용 스트리밍 펌웨어.
  포맷: START:v0,v1,...,vN:END  (N = pixelCount-1, 칩에 따라 192/768 자동)
  부팅 시 INFO 한 줄로 해상도를 알려주므로 UI에서 자동 적응에 활용 가능:
    INFO:CHIP=MLX90641,COLS=16,ROWS=12
*/
#include <MLX9064x_Universal.h>

MLX9064xUniversal cam;
float frame[MLX9064X_MAX_PIXELS];

void setup() {
  Serial.begin(115200);
  while (!Serial) delay(10);

  if (!cam.begin()) {
    while (1) { Serial.printf("ERR_INIT:%d\n", cam.lastError()); delay(1000); }
  }
  cam.setRefreshRate(MLX9064X_RATE_8HZ);

  Serial.printf("INFO:CHIP=%s,COLS=%u,ROWS=%u\n",
                cam.chip() == MLX9064X_MLX90641 ? "MLX90641" : "MLX90640",
                cam.width(), cam.height());
  delay(300);
}

void loop() {
  if (cam.readFrame(frame) != 0) {
    Serial.printf("ERR_FRAME:%d\n", cam.lastError());
    delay(50);
    return;
  }
  const uint16_t n = cam.pixelCount();
  Serial.print("START:");
  for (uint16_t i = 0; i < n; i++) {
    Serial.print(frame[i], 2);
    if (i < n - 1) Serial.print(",");
  }
  Serial.println(":END");
}
