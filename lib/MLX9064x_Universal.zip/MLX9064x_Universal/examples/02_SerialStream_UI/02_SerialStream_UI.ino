/*
  02_SerialStream_UI — UI 앱(Web Serial)용 CSV 스트리밍 펌웨어 자리표시자

  이 예제는 자리표시자입니다. 선생님이 사용 중인 실제 스트리밍 펌웨어
  (한 프레임당 START:t0,...,t191:END 출력)를 여기에 넣으세요.

  03_BasicReadings 를 기반으로, loop() 출력만 아래 형식으로 바꾸면 됩니다:
    Serial.print("START:");
    for (int i = 0; i < 192; i++) { Serial.print(result[i], 2); if (i < 191) Serial.print(','); }
    Serial.println(":END");
  - 보드: Arduino Nano ESP32, 115200bps
  - 업로드 후 UI(mlx90641_thermal_ui.html)에서 장치 연결
*/
void setup() {}
void loop() {}
